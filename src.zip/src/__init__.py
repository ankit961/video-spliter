"""Video Split Pipeline v2 - Production-grade video segmentation."""

__version__ = "2.0.0"
